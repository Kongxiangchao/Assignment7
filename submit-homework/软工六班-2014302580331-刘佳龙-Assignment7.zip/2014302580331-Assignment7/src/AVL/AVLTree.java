package AVL;

import javax.swing.JTree;

/**
 *����ƽ������ʵ��
 *@author kiritor 
 */
public class AVLTree< T extends Comparable< ? super T>> implements IAVLTree
{
     public static class ANode< T>{//avl���ڵ�
        
        @SuppressWarnings("unused")
		ANode( T theElement )
        {
            this( theElement, null, null );
        }
        ANode( T theElement, ANode< T> lt, ANode< T> rt )
        {
            element  = theElement;
            left     = lt;
            right    = rt;
            height   = 0;
        }
        T           element;      // �ڵ��е�����
        ANode< T>  left;         // �����
        ANode< T>  right;        // �Ҷ���
        int         height;       // �ڵ�ĸ߶�
    }
     
    private ANode< T> root;//avl����
   
    public AVLTree( )
    {
        root = null;
    }
   //��avl���в������ݣ��ظ����ݸ���
    public void insert( T x )
    {
        root = insert( x, root );
    }
   
    //��avl��ɾ������,���ﲢδʵ��
    public void remove( T x )
    {
        System.out.println( "Sorry, remove unimplemented" );
    }
  
     //��avl��������С������
    public T findMin( )
    {
        if( isEmpty( ) )
            System.out.println("����");;
        return findMin( root ).element;
    }
    //��avl��������������
    public T findMax( )
    {
        if( isEmpty( ) )
            System.out.println("����");
        return findMax( root ).element;
    }
   //����
    public boolean contains( T x )
    {
        return contains( x, root );
    }
   
    public void makeEmpty( )
    {
        root = null;
    }
    
    public boolean isEmpty( )
    {
        return root == null;
    }
    //�������avl��
    public void printTree1( )
    {
        if( isEmpty( ) )
            System.out.println( "Empty tree" );
        else
            printTree( root );
    }
    
    @Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void insert(int id, Node newNode) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void delete(int el) {
		// TODO Auto-generated method stub
		ANode<T> tmp,node,p=root,prev=null;
	    /*find the node to be deleted*/
	    while(p!=null&&p.height!=el)
	    {
	    prev=p;
	    if(p.height<el)
	    p=p.right;
	    else p=p.left;
	    }
	    /*find end*/
	    node=p;
	    if(p!=null&&p.height==el)
	    {
	    if(node.right==null)
	    //node has no right child then its left child (if any) is attached to 
	    node=node.left;
	    //its parent
	      else if(node.left==null)
	      //node has no left child then its right child (if any) is attched to
	      node=node.right;
	      //its parent
	    else{
	    tmp=node.left;  
	    while(tmp.right!=null)
	    tmp=tmp.right;
//	    tem=node.right;
	    //establish the link between the rightmost node of the left subtree and the right subtree
	    node=node.left;
	    }
	    if(p==root)
	    {
	    root=node;
	    }
	    else if (prev.left==p)
	    {
	    prev.left=node;
	    }
	    else prev.right=node;
	    }
	    else if(root!=null)
	      {
	    System.out.println("the node is not in the tree");
	    }
	    else System.out.println("The tree is empty");
	}
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		return null;
	}
   
    private ANode< T> insert( T x, ANode< T> t )
    {
        if( t == null )
            return new ANode< T>( x, null, null );
        
        int compareResult = x.compareTo( t.element );
        
        if( compareResult < 0 )
        {
            t.left = insert( x, t.left );//��x������������
            if( height( t.left ) - height( t.right ) == 2 )
                if( x.compareTo( t.left.element ) < 0 )//LL
                    t = rotateWithLeftChild( t );
                else   //LR�ͣ������ͣ�
                    t = doubleWithLeftChild( t );
        }
        else if( compareResult > 0 )
        {
            t.right = insert( x, t.right );
            if( height( t.right ) - height( t.left ) == 2 )
                if( x.compareTo( t.right.element ) > 0 )//RR
                    t = rotateWithRightChild( t );
                else                           //RL
                    t = doubleWithRightChild( t );
        }
        else
            ; 
        t.height = Math.max( height( t.left ), height( t.right ) ) + 1;
        return t;
    }
   
     //����С
    private ANode< T> findMin( ANode< T> t )
    {
        if( t == null )
            return t;
        while( t.left != null )
            t = t.left;
        return t;
    }
    //�����
    private ANode< T> findMax( ANode< T> t )
    {
        if( t == null )
            return t;
        while( t.right != null )
            t = t.right;
        return t;
    }
    //���������ң�
    private boolean contains( T x, ANode t )
    {
        while( t != null )
        {
            int compareResult = x.compareTo( (T) t.element );
            
            if( compareResult < 0 )
                t = t.left;
            else if( compareResult > 0 )
                t = t.right;
            else
                return true;    // Match
        }
        return false;   // No match
    }
   //�������avl��
    private void printTree( ANode< T> t )
    {
        if( t != null )
        {
            printTree( t.left );
            System.out.println( t.element );
            printTree( t.right );
        }
    }
    
  //��߶� 
    private int height( ANode< T> t )
    {
        return t == null ? -1 : t.height;
    }
    //����������ת,������LL��
    private ANode< T> rotateWithLeftChild( ANode< T> k2 )
    {
        ANode< T> k1 = k2.left;
        k2.left = k1.right;
        k1.right = k2;
        k2.height = Math.max( height( k2.left ), height( k2.right ) ) + 1;
        k1.height = Math.max( height( k1.left ), k2.height ) + 1;
        return k1;
    }
    //����������ת��������RR��
    private ANode< T> rotateWithRightChild( ANode< T> k1 )
    {
        ANode< T> k2 = k1.right;
        k1.right = k2.left;
        k2.left = k1;
        k1.height = Math.max( height( k1.left ), height( k1.right ) ) + 1;
        k2.height = Math.max( height( k2.right ), k1.height ) + 1;
        return k2;
    }
    //˫��ת��������LR��
    private ANode< T> doubleWithLeftChild( ANode< T> k3 )
    {
        k3.left = rotateWithRightChild( k3.left );
        return rotateWithLeftChild( k3 );
    }
    //˫��ת,������RL��
    private ANode< T> doubleWithRightChild( ANode< T> k1 )
    {
        k1.right = rotateWithLeftChild( k1.right );
        return rotateWithRightChild( k1 );
    }
       // Test program
    public static void main( String [ ] args )
    { 
        AVLTree< Integer> t = new AVLTree< Integer>( );
        int num = 100;
        int GAP  =   17;
        System.out.println( "Checking... (no more output means success)" );
        for( int i = GAP; i != 0; i = ( i + GAP ) % num )
        	t.insert( i );
           t.printTree1( );
    }
	
}