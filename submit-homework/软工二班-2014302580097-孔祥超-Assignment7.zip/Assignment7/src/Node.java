
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	public int balanceFactor;
	
	public Node(int id){
		this.id = id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id2) {
		// TODO �Զ����ɵķ������
		this.id = id2;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	public int compare(int id2) {
		// TODO �Զ����ɵķ������
		if(this.id > id){
			return 1;
		}else if(this.id < id){
			return -1;
		}
		return 0;
	}
	public boolean hasChild(int id) {
		// TODO �Զ����ɵķ������
		return children[id] != null;
	}
	public int compare(Node newNode) {
		// TODO �Զ����ɵķ������
		if(newNode == null){
			return 1;
		}
		return compare(newNode.getId());
	}
	public int getIndexOfParent() {
		// TODO �Զ����ɵķ������
		if(parent == null){
			return -1;
		}
		if(parent.hasChild(0)){
			if(compare(parent.getChildren()[0]) == 0){
				return 0;
			}
		}
		return 1;
	}
	
	

}
