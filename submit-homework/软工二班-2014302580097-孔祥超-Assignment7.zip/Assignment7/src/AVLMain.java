import java.util.Iterator;
import java.util.NoSuchElementException;

public class AVLMain {
	
	AVLTree tree = new AVLTree();  
    System.out.println("------����------"); 
    tree.get(50);
    System.out.print(50+" ");  
    tree.get(66);  
    System.out.print(66+" ");  
    for(int i=0;i<10;i++){  
        int ran = (int)(Math.random() * 100);
        System.out.print(ran+" ");  
        tree.get(ran);  
    }  
    System.out.println("------ɾ��------");  
    tree.remove(50);  
    tree.remove(66);  
      
    System.out.println();  
    Iterator<Integer> it = tree.itrator();  
    while(it.hasNext()){  
        System.out.print(it.next()+" ");  
    }  
} 
	}

