import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;


public class AVLTree {
private Node root;
	
	public AVLTree(){
		root = null;
	}
	
	private void LRotation(Node s){
		
		Node r = s.getChildren()[0];
		
		if(r.getBalanceFactor() == 1){			//LL��ת
			s.setChild(r.getChildren()[1], 0);
			r.setChild(s, 1);
			s.balanceFactor = 0;                //sָʾ�������ĸ�
			s = r;
		}else{							        //LR��ת
			Node u = r.getChildren()[1];
			r.setChild(u.getChildren()[0], 1);
			u.setChild(r, 0);
			s.setChild(u.getChildren()[1], 0);
			u.setChild(s, 1);
			
			switch(u.getBalanceFactor()){
			case 1:s.balanceFactor = -1; r.balanceFactor = 0; break;
			case 0:s.balanceFactor = r.balanceFactor = 0; break;
			case -1:s.balanceFactor = 0; r.balanceFactor = 1;
		}
			
		s = u;                                   //sָʾ�������ĸ�

		}
		
		s.balanceFactor = 0;                     //���s��ƽ������Ϊ0
		
	}
	
	private void RRotation(Node s){
		
		Node r = s.getChildren()[1];
		
		if(r.getBalanceFactor() == -1){			//RR��ת
			s.setChild(r.getChildren()[0], 1);
			r.setChild(s, 0);
			s.balanceFactor = 0;
			s = r;
		}else{							        //RL��ת
			Node u = r.getChildren()[0];
			r.setChild(u.getChildren()[1], 0);
			u.setChild(r, 1);
			s.setChild(u.getChildren()[0], 1);
			u.setChild(s, 0);

			switch(u.getBalanceFactor()){
			case 1:s.balanceFactor = -1; r.balanceFactor = 0; break;
			case 0:s.balanceFactor = r.balanceFactor = 0; break;
			case -1:s.balanceFactor = 0; r.balanceFactor = 1;
		}
			s = u;
		}
		
	}
	
	/**
	 * ���������ڵ��id��data
	 * @param a
	 * @param b
	 */
	private void swapData(Node a, Node b){
		int tempId = a.getId();
		Object tempData = a.getData();
		a.setId(b.getId());
		a.setData(b.getData());
		b.setId(tempId);
		b.setData(tempData);	
	}
	
	/**
	 * ��ȡ��parentNode�µ�ĳid�Ľڵ�
	 * @param id
	 * @param parentNode
	 * @return �������Ľڵ����null
	 */
	private Node get(int id, Node parentNode){
		Node result = null;
		if(parentNode.compare(id) == 0){
			result = parentNode;
		}else if(parentNode.compare(id) == 1){
			if(parentNode.hasChild(0)){
				result = get(id, parentNode.getChildren()[0]);
			}
		}else{
			if(parentNode.hasChild(1)){
				result = get(id, parentNode.getChildren()[1]);
			}
		}
		return result;
	}

	/**
	 * ˽�в��뺯��
	 * @param p
	 * @param newNode
	 * @return ���ز���״̬���ƺ�û���õ���
	 */
	private int insert(Node p, Node newNode){
		if(p.compare(newNode) == 1){
			if(!p.hasChild(0)){
				//�����½ڵ�
				p.setChild(newNode, 0);
				p.getChildren()[0].setParent(p);
			}else{
				//����ݹ�
				insert(p.getChildren()[0],newNode);
			}
			//�ж��Ƿ������ת
			if(p.getBalanceFactor()>1){
				LRotation(p);
			}
		}else if(p.compare(newNode)==0){
			//�Ѵ���ͬ��Ԫ��
			return -1;
		}else{
			if(!p.hasChild(1)){
				p.setChild(newNode, 1);
				p.getChildren()[1].setParent(p);
			}else{
				insert(p.getChildren()[1],newNode);
			}
			if(p.getBalanceFactor()<-1){
				RRotation(p);
			}
		}
		return 0;
	}
	
	private void delete(int id,Node p){
		Node replaceNode = null;
		Node deleteNode = get(id);
		if(deleteNode == null){
			return;
		}
		//��ɾ��Ԫ�����������������ת����ֻ��һ�����������
		if(deleteNode.hasChild(0) && deleteNode.hasChild(1)){
			Node s = deleteNode.getChildren()[1];
			while(s.hasChild(0)){
				s = s.getChildren()[0];
			}
			swapData(deleteNode,s);
			deleteNode = s;
		}
		//�ֱ�����һ����������û�����������
		if(deleteNode.hasChild(0)){
			replaceNode = deleteNode.getChildren()[0];
		}else if(deleteNode.hasChild(1)){
			replaceNode = deleteNode.getChildren()[1];
		}else{
			replaceNode = null;
		}
		//��ɾ��Ԫ��Ϊ���ڵ�ʱ
		if(deleteNode.compare(root) == 0){
			root = replaceNode;
			return;
		}else{ 
			deleteNode.getParent().setChild(replaceNode, deleteNode.getIndexOfParent());
			if(deleteNode.getParent().getBalanceFactor() < -1){
				RRotation(deleteNode.getParent());
			}else if(deleteNode.getParent().getBalanceFactor() > 1){
				LRotation(deleteNode.getParent());
			}

		}
	}
	
	public Node get(int id) {
		// TODO Auto-generated method stub
		Node n = get(id,root);
		System.out.println("����get" + n);
		return n;
	}

	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		if(root == null){
			root = newNode;
		}else{
			insert(root,newNode);
		}	
	}
	
	public void delete(int id) {
		// TODO Auto-generated method stub
		if(root == null){
			return;
		}
		delete(id, root);
	}
	
	/**
	 * ˽�б������Node�ڵ�ĺ���
	 * @param n
	 * @return ����DefaultMutableTreeNode�Ľڵ㣬�ڵ��ڰ������²���״�ṹ
	 */
	private DefaultMutableTreeNode printTree(Node n){
		if(n != null){
			DefaultMutableTreeNode tempNode = new DefaultMutableTreeNode(n.getId());
			if(n.hasChild(0)){
				tempNode.add(printTree(n.getChildren()[0]));
			}
			if(n.hasChild(1)){
				tempNode.add(printTree(n.getChildren()[1]));
			}
			return tempNode;
		}
		return null;
	}

	public JTree printTree() {
		// TODO Auto-generated method stub
		DefaultMutableTreeNode rootNode = printTree(root);	
		if(rootNode == null){
			rootNode = new DefaultMutableTreeNode("������Ϊ��");
		}
		DefaultTreeModel tm = new DefaultTreeModel(rootNode);
		return new JTree(tm);
	}

}


